# Before you start — about this data

The wiki data in `data/german-collusion-wiki/` comes from collusion.wiki and has
**no stated licence**. It is shared with you for this coding task only.

Please:
- do not redistribute it or post any of it publicly,
- do not paste page text or messages into any chatbot, LLM or online tool,
- delete the folder when you have finished.

Your labels contain no page text, so they are safe to send back.
