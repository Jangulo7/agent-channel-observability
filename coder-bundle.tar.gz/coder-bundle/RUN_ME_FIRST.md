# Run me first

1. Install: `uv sync --extra dev`  (or `pip install -e .`)
2. Check:   `bash coder-kit/check_setup.sh`
3. Read:    `coder-kit/README.md`

Everything you need is in `coder-kit/`. Start there.
